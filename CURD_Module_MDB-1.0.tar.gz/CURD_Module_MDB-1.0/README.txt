CURD_Module_MDB
Helper module to connect to the Grazioso Salvare MongoDB database