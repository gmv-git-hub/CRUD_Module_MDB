from setuptools import setup

setup(
    name='CURD_Module_MDB',
    version='1.1',
    description='Helper module to connect to the Grazioso Salvare MongoDB database',
    author='Gianmarco Vendramin',
    author_email='gianmarco.vendramin@snhu.edu',
    url='https://github.com/gmv-git-hub/CURD_Module_MDB',
    py_modules=['CURD_Module_MDB'],
)
